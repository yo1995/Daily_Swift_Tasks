## TicTacToe

![logo](/tictactoe/resources/logo.png)

partially inspired by https://github.com/cocoascientist/TicTacToe

Also, learned a lot from: https://freecontent.manning.com/classic-computer-science-problems-in-swift-tic-tac-toe/

Please refer to [Video](/tictactoe/progress-notes/release1_190710.mov) for more details
